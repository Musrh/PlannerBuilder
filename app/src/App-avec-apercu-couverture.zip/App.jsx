import { useEffect, useState } from 'react'
import { jsPDF } from 'jspdf'
import AdminMockups from './AdminMockups.jsx'
import AdminLocalPanel from './AdminLocalPanel.jsx'
import AuthGate from './AuthGate.jsx'
import { usePlannerBuilderAuth } from './AuthGate.jsx'
import './App.css'

const WHOP_MONTHLY_URL = 'https://whop.com/checkout/plan_s2EaEjQLNmqtP'
const WHOP_ANNUAL_URL = 'https://whop.com/checkout/plan_MYoWQwEMrukh'


const templates = [
  { id: 'daily', name: 'Agenda quotidien', category: 'Organisation', icon: '☀️', pages: 30 },
  { id: 'weekly', name: 'Planner hebdomadaire', category: 'Organisation', icon: '📅', pages: 12 },
  { id: 'monthly', name: 'Planner mensuel', category: 'Organisation', icon: '🗓️', pages: 12 },
  { id: 'food', name: 'Planner alimentaire', category: 'Repas', icon: '🥗', pages: 52 },
  { id: 'student', name: 'Planner étudiant', category: 'Études', icon: '📚', pages: 30 },
  { id: 'budget', name: 'Budget personnel', category: 'Finances', icon: '💰', pages: 12 },
  { id: 'habits', name: 'Suivi des habitudes', category: 'Bien-être', icon: '🌱', pages: 30 },
  { id: 'business', name: 'Planner professionnel', category: 'Travail', icon: '💼', pages: 20 },
]

const pageContent = {
  daily: {
    title: 'Ma journée',
    subtitle: 'Organiser chaque instant avec intention.',
    sections: ['Mes priorités', 'Planning de la journée', 'À ne pas oublier', 'Notes et idées'],
    rows: ['Priorité 1', 'Priorité 2', 'Priorité 3'],
  },
  weekly: {
    title: 'Ma semaine',
    subtitle: 'Une semaine organisée à mon rythme.',
    sections: ['Mes objectifs', 'Lundi – Dimanche', 'Rendez-vous', 'Notes'],
    rows: ['Objectif principal', 'Tâches importantes', 'Moment pour moi'],
  },
  monthly: {
    title: 'Mon mois',
    subtitle: 'Prendre du recul et préparer la suite.',
    sections: ['Objectifs du mois', 'Dates importantes', 'Projets', 'Bilan du mois'],
    rows: ['Objectif 1', 'Objectif 2', 'Objectif 3'],
  },
  food: {
    title: 'Mon planner alimentaire',
    subtitle: 'Mieux manger, planifier et savourer.',
    sections: ['Menu de la semaine', 'Liste de courses', 'Préparation des repas', 'Notes nutrition'],
    rows: ['Petit-déjeuner', 'Déjeuner', 'Dîner'],
  },
  student: {
    title: 'Mon planner étudiant',
    subtitle: 'Apprendre, progresser et réussir.',
    sections: ['Objectifs scolaires', 'Devoirs et examens', 'Planning de révision', 'Notes de cours'],
    rows: ['Matière 1', 'Matière 2', 'Matière 3'],
  },
  budget: {
    title: 'Mon budget',
    subtitle: 'Garder le contrôle de mes finances.',
    sections: ['Revenus du mois', 'Dépenses prévues', 'Épargne', 'Bilan financier'],
    rows: ['Logement', 'Alimentation', 'Transport'],
  },
  habits: {
    title: 'Mes habitudes',
    subtitle: 'Les petits gestes créent de grands changements.',
    sections: ['Habitudes à suivre', 'Suivi de la semaine', 'Mes progrès', 'Réflexions'],
    rows: ['Boire de l’eau', 'Bouger chaque jour', 'Lire 10 minutes'],
  },
  business: {
    title: 'Mon planner professionnel',
    subtitle: 'Donner de la clarté à mes projets.',
    sections: ['Objectifs professionnels', 'Tâches prioritaires', 'Réunions', 'Prochaines étapes'],
    rows: ['Projet prioritaire', 'Action à réaliser', 'Suivi nécessaire'],
  },
}

function App() {
  const { user, plan, isAdmin } = usePlannerBuilderAuth()
  const isUnlimited = plan === 'pro' || isAdmin

  const [showMockups, setShowMockups] = useState(false)
  const [showAdminPanel, setShowAdminPanel] = useState(false)
  const [selectedId, setSelectedId] = useState('food')
  const [visualStyle, setVisualStyle] = useState('minimaliste')
  const [coverId, setCoverId] = useState('minimaliste')
  const [coverImage, setCoverImage] = useState('')
  const [previewMode, setPreviewMode] = useState('cover')
  const [pages, setPages] = useState(12)
  const [primary, setPrimary] = useState('#718B70')
  const [background, setBackground] = useState('#F7F5EF')
  const [titleBackground, setTitleBackground] = useState('#718B70')
  const [titleTextColor, setTitleTextColor] = useState('#FFFFFF')
  const [font, setFont] = useState('moderne')
  const [density, setDensity] = useState('confortable')
  const [category, setCategory] = useState('Tous')
  const [notice, setNotice] = useState('')
  const exportStorageKey = `plannerbuilder_free_exports_${user?.uid || 'guest'}`
  const [freeExports, setFreeExports] = useState(0)
  const [customContent, setCustomContent] = useState(() =>
    JSON.parse(JSON.stringify(pageContent))
  )
  const [coverLabelStyles, setCoverLabelStyles] = useState({
    brand: { width: 70, height: 10, textColor: '#718B70', background: '#FFFFFF', hidden: false },
    title: { width: 90, height: 28, textColor: '#252525', background: '#FFFFFF', hidden: false },
    subtitle: { width: 85, height: 16, textColor: '#555555', background: '#FFFFFF', hidden: false },
    category: { width: 60, height: 10, textColor: '#718B70', background: '#FFFFFF', hidden: false },
    footer: { width: 40, height: 7, textColor: '#777777', background: '#FFFFFF', hidden: false },
  })
  function updateCoverLabelStyle(kind, field, value) {
    setCoverLabelStyles(current => ({ ...current, [kind]: { ...current[kind], [field]: value } }))
  }

  useEffect(() => {
    const saved = Number(localStorage.getItem(exportStorageKey) || 0)
    setFreeExports(Number.isFinite(saved) && saved >= 0 ? Math.floor(saved) : 0)
  }, [exportStorageKey])

  const selected = templates.find((item) => item.id === selectedId)
  const content = customContent[selectedId] || pageContent[selectedId]

  function updateContent(field, value, index = null) {
    setCustomContent((current) => {
      const nextTemplate = { ...current[selectedId] }
      if (index === null) nextTemplate[field] = value
      else nextTemplate[field] = nextTemplate[field].map((item, itemIndex) =>
        itemIndex === index ? value : item
      )
      return { ...current, [selectedId]: nextTemplate }
    })
  }
  const categories = ['Tous', ...new Set(templates.map((item) => item.category))]
  const filtered = category === 'Tous'
    ? templates
    : templates.filter((item) => item.category === category)

  function chooseTemplate(template) {
    setSelectedId(template.id)
    setPages(template.pages)
    setNotice('')
  }

  function exportPDF() {
    if (!isUnlimited && freeExports >= 3) {
      setNotice(
        'Vous avez utilisé vos 3 exports gratuits. Passez à PlannerBuilder Pro pour exporter sans limite.'
      )
      return
    }

    try {
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      })

      const pageWidth = 210
      const pageHeight = 297
      const margin = 15
      const usableWidth = pageWidth - margin * 2

      const toRgb = (hex) => {
        const value = hex.replace('#', '')
        return [
          parseInt(value.substring(0, 2), 16),
          parseInt(value.substring(2, 4), 16),
          parseInt(value.substring(4, 6), 16),
        ]
      }

      const primaryRgb = toRgb(primary)
      const backgroundRgb = toRgb(background)
      const titleBackgroundRgb = toRgb(titleBackground)
      const titleTextRgb = toRgb(titleTextColor)
      const fontMap = {
        moderne: 'helvetica',
        classique: 'times',
        elegante: 'times',
      }
      const pdfFont = fontMap[font] || 'helvetica'
      const compact = density === 'compacte'
      const sectionGap = compact ? 5 : 8
      const lineGap = compact ? 6 : 8

      // PAGE 1 : couverture indépendante du style intérieur
      const coverThemes = {
        minimaliste: { bg: [250, 249, 246], accent: [55, 55, 55], shape: 'minimal' },
        nature: { bg: [237, 242, 231], accent: [74, 112, 76], shape: 'nature' },
        professionnelle: { bg: [238, 242, 248], accent: [39, 63, 95], shape: 'professional' },
        coloree: { bg: [255, 239, 220], accent: [190, 75, 67], shape: 'color' },
        elegante: { bg: [247, 241, 235], accent: [128, 91, 72], shape: 'elegant' },
        florale: { bg: [250, 237, 242], accent: [160, 83, 119], shape: 'floral' },
        geometrique: { bg: [237, 239, 247], accent: [70, 75, 150], shape: 'geometric' },
        sombre: { bg: [35, 38, 43], accent: [225, 192, 125], shape: 'dark' },
      }
      const cover = coverThemes[coverId] || coverThemes.minimaliste

      if (coverImage) {
        const format = coverImage.startsWith('data:image/png') ? 'PNG'
          : coverImage.startsWith('data:image/webp') ? 'WEBP' : 'JPEG'
        doc.addImage(coverImage, format, 0, 0, pageWidth, pageHeight)
        doc.setFillColor(255, 255, 255)
        doc.roundedRect(18, 95, pageWidth - 36, 90, 4, 4, 'F')
        doc.setTextColor(30, 30, 30)
      } else {
        doc.setFillColor(...cover.bg)
        doc.rect(0, 0, pageWidth, pageHeight, 'F')
        doc.setFillColor(...cover.accent)

        if (cover.shape === 'nature') {
          doc.circle(175, 45, 30, 'F')
          doc.circle(25, 245, 35, 'F')
        } else if (cover.shape === 'professional') {
          doc.rect(0, 0, 12, pageHeight, 'F')
          doc.rect(25, 35, 160, 1.5, 'F')
        } else if (cover.shape === 'color') {
          doc.circle(170, 50, 38, 'F')
          doc.circle(35, 260, 27, 'F')
        } else if (cover.shape === 'elegant') {
          doc.setDrawColor(...cover.accent)
          doc.setLineWidth(0.8)
          doc.rect(12, 12, pageWidth - 24, pageHeight - 24, 'S')
          doc.rect(17, 17, pageWidth - 34, pageHeight - 34, 'S')
        } else if (cover.shape === 'floral') {
          doc.circle(35, 40, 18, 'F')
          doc.circle(175, 255, 25, 'F')
          doc.circle(35, 58, 8, 'F')
        } else if (cover.shape === 'geometric') {
          doc.triangle(150, 20, 205, 80, 155, 105, 'F')
          doc.rect(0, 230, pageWidth, 67, 'F')
        } else if (cover.shape === 'dark') {
          doc.setDrawColor(...cover.accent)
          doc.setLineWidth(1.2)
          doc.rect(12, 12, pageWidth - 24, pageHeight - 24, 'S')
        } else {
          doc.rect(20, 35, 42, 1, 'F')
          doc.rect(20, 40, 24, 1, 'F')
        }

        doc.setTextColor(...cover.accent)
      }

      const drawCoverLabel = (key, text, y, fontName, fontStyle, fontSize) => {
        const style = coverLabelStyles[key]
        if (!style || style.hidden || !text) return
        const w = pageWidth * Math.max(10, Math.min(100, Number(style.width) || 50)) / 100
        const h = Math.max(5, Math.min(40, Number(style.height) || 10))
        const x = (pageWidth - w) / 2
        doc.setFillColor(...toRgb(style.background || '#FFFFFF'))
        doc.roundedRect(x, y - h + 2, w, h, 2, 2, 'F')
        doc.setFont(fontName, fontStyle)
        doc.setFontSize(fontSize)
        doc.setTextColor(...toRgb(style.textColor || '#333333'))
        const lines = doc.splitTextToSize(String(text), Math.max(10, w - 8))
        doc.text(lines, pageWidth / 2, y - Math.max(1, (lines.length - 1) * fontSize * 0.35), { align: 'center', maxWidth: w - 8 })
      }
      drawCoverLabel('brand', 'PLANNERBUILDER', 88, 'helvetica', 'bold', 11)
      drawCoverLabel('title', content.title, 125, pdfFont, 'bold', 27)
      drawCoverLabel('subtitle', content.subtitle, 153, pdfFont, 'normal', 12)
      drawCoverLabel('category', selected.category.toUpperCase(), 185, 'helvetica', 'normal', 10)
      drawCoverLabel('footer', 'COUVERTURE', pageHeight - 18, 'helvetica', 'normal', 8)

      // Les pages intérieures commencent toujours en page 2.
      for (let pageIndex = 0; pageIndex < pages; pageIndex += 1) {
        doc.addPage()

        doc.setFillColor(...backgroundRgb)
        doc.rect(0, 0, pageWidth, pageHeight, 'F')

        doc.setDrawColor(...primaryRgb)
        doc.setLineWidth(0.8)
        doc.line(margin, 13, pageWidth - margin, 13)

        doc.setFont('helvetica', 'bold')
        doc.setFontSize(8)
        doc.setTextColor(...primaryRgb)
        doc.text('MON PLANNER', margin, 10)
        doc.text(String(pageIndex + 1).padStart(2, '0'), pageWidth - margin, 10, {
          align: 'right',
        })

        doc.setFont(pdfFont, 'normal')
        doc.setFontSize(10)
        doc.setTextColor(...primaryRgb)
        doc.text(selected.category.toUpperCase(), margin, 26)

        doc.setFont(pdfFont, 'bold')
        doc.setFontSize(23)
        doc.setTextColor(0, 0, 0)
        const titleLines = doc.splitTextToSize(content.title, usableWidth)
        doc.text(titleLines, margin, 37)

        let y = 37 + titleLines.length * 9
        doc.setFont(pdfFont, 'normal')
        doc.setFontSize(10)
        doc.setTextColor(90, 95, 85)
        const subtitleLines = doc.splitTextToSize(content.subtitle, usableWidth)
        doc.text(subtitleLines, margin, y)
        y += subtitleLines.length * 5 + 8

        doc.setFont('helvetica', 'bold')
        doc.setFontSize(8)
        doc.setTextColor(...primaryRgb)
        doc.text('DATE', margin, y)
        doc.setDrawColor(190, 195, 180)
        doc.setLineWidth(0.3)
        doc.line(margin + 15, y + 1, pageWidth - margin, y + 1)
        y += 10

        content.sections.forEach((section, sectionIndex) => {
          const bottomLimit = pageHeight - 19
          if (y + 25 > bottomLimit) return

          doc.setFillColor(255, 255, 255)
          doc.setDrawColor(...primaryRgb)
          doc.setLineWidth(0.25)
          doc.roundedRect(margin, y, usableWidth, compact ? 39 : 44, 3, 3, 'FD')

          doc.setFillColor(...titleBackgroundRgb)
          doc.roundedRect(margin, y, usableWidth, 9, 2, 2, 'F')
          doc.setFont('helvetica', 'bold')
          doc.setFontSize(11)
          doc.setTextColor(...titleTextRgb)
          doc.text(section, margin + 4, y + 6)

          let rowY = y + 16
          const rowCount = compact ? 3 : 3

          for (let rowIndex = 0; rowIndex < rowCount; rowIndex += 1) {
            if (rowY > y + (compact ? 35 : 40)) break

            const rowText = sectionIndex === 0
              ? (content.rows[rowIndex] || '')
              : ''

            if (['food', 'student', 'habits'].includes(selectedId)) {
              doc.setDrawColor(...primaryRgb)
              doc.roundedRect(margin + 4, rowY - 3, 3, 3, 0.5, 0.5, 'S')
            }

            if (rowText) {
              doc.setFont(pdfFont, 'bold')
              doc.setFontSize(9)
              doc.setTextColor(50, 50, 50)
              doc.text(rowText, margin + 14, rowY + 1, { maxWidth: usableWidth - 20 })
            }

            doc.setDrawColor(215, 218, 207)
            doc.line(
              margin + (['food', 'student', 'habits'].includes(selectedId) ? 34 : 5),
              rowY + 2,
              pageWidth - margin - 5,
              rowY + 2
            )
            rowY += lineGap
          }

          y += (compact ? 39 : 44) + sectionGap
        })

        doc.setDrawColor(...primaryRgb)
        doc.setLineWidth(0.4)
        doc.line(margin, pageHeight - 13, pageWidth - margin, pageHeight - 13)

        doc.setFont('helvetica', 'normal')
        doc.setFontSize(8)
        doc.setTextColor(...primaryRgb)
        doc.text('PLANNERBUILDER', margin, pageHeight - 8)
        doc.text(
          `PAGE ${pageIndex + 1} / ${pages}`,
          pageWidth - margin,
          pageHeight - 8,
          { align: 'right' }
        )
      }

      const safeName = selected.name
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '')

      doc.save(`${safeName || 'planner'}-${pages}-pages.pdf`)

      if (isUnlimited) {
        setNotice(
          `PDF créé : ${pages + 1} page(s), couverture comprise.`
        )
      } else {
        const nextExports = freeExports + 1

        localStorage.setItem(
          exportStorageKey,
          String(nextExports)
        )
        setFreeExports(nextExports)

        setNotice(
          `PDF créé : ${pages + 1} page(s), couverture comprise. ${3 - nextExports} export(s) gratuit(s) restant(s).`
        )
      }
    } catch (error) {
      console.error('Erreur export PDF :', error)
      setNotice('Impossible de générer le PDF. Vérifie le terminal et réessaie.')
    }
  }

  return (
    <main
      className={`app-shell density-${density} font-${font}`}
      style={{
        '--primary': primary,
        '--paper': background,
        '--title-background': titleBackground,
        '--title-text': titleTextColor,
      }}
    >
      <header className="topbar">
        <a className="brand" href="#top" aria-label="PlannerBuilder accueil">
          <span className="brand-mark">P</span>
          <span>Planner<span className="brand-light">Builder</span></span>
        </a>
        <span className="private-label"><span /> Espace de création</span>
        {import.meta.env.DEV && (
          <button
            type="button"
            className="mockup-dev-toggle"
            onClick={() => setShowMockups((value) => !value)}
          >
            {showMockups ? 'Fermer les mockups' : 'Mockups (prototype)'}
          </button>
        )}
        {isAdmin && (
          <button
            type="button"
            className="mockup-dev-toggle"
            onClick={() => setShowAdminPanel((value) => !value)}
          >
            {showAdminPanel ? 'Fermer administration' : 'Administration'}
          </button>
        )}
      </header>

      <section className="welcome" id="top">
        <div>
          <p className="eyebrow">VOTRE ATELIER CRÉATIF</p>
          <h1>Créez un planner <em>à votre image.</em></h1>
          <p className="welcome-text">
            Choisissez un modèle, personnalisez son style et préparez votre document.
          </p>
        </div>
        <div className="welcome-decoration" aria-hidden="true">❋</div>
      </section>

      <section className="account-status panel" aria-label="Statut du compte" style={{ maxWidth: 1100, margin: '18px auto', padding: '14px 18px' }}>
        <strong>Compte connecté :</strong> {user?.email || 'Adresse indisponible'}
        <span style={{ marginLeft: 16 }}><strong>Abonnement :</strong> {isAdmin ? 'Administrateur' : plan === 'pro' ? 'PlannerBuilder Pro' : 'PlannerBuilder Free'}</span>
        {!isUnlimited && <span style={{ marginLeft: 16 }}><strong>Exports gratuits restants :</strong> {Math.max(0, 3 - freeExports)} / 3</span>}
      </section>

      {import.meta.env.DEV && showMockups && <AdminMockups />}
      {isAdmin && showAdminPanel && <AdminLocalPanel />}

      <div className="workspace">
        <aside className="sidebar panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">ÉTAPE 1</p>
              <h2>Mes modèles</h2>
            </div>
            <span className="count">{filtered.length}</span>
          </div>

          <label className="field-label" htmlFor="category">Catégorie</label>
          <select id="category" value={category} onChange={(event) => setCategory(event.target.value)}>
            {categories.map((item) => <option key={item}>{item}</option>)}
          </select>

          <div className="template-list">
            {filtered.map((template) => (
              <button
                className={`template-option ${selectedId === template.id ? 'selected' : ''}`}
                key={template.id}
                onClick={() => chooseTemplate(template)}
                type="button"
              >
                <span className="template-icon">{template.icon}</span>
                <span className="template-name">
                  <strong>{template.name}</strong>
                  <small>{template.category}</small>
                </span>
                {selectedId === template.id && <span className="selected-check">✓</span>}
              </button>
            ))}
          </div>

          <div className="sidebar-tip">
            <span>✦</span>
            <p>Votre créativité, vos règles. Personnalisez votre document à tout moment.</p>
          </div>
        </aside>

        <section className="preview-column">
          <div className="preview-toolbar">
            <div>
              <p className="eyebrow">APERÇU EN DIRECT</p>
              <h2>{selected.name}</h2>
            </div>
            <span className="preview-status"><span /> Prévisualisation</span>
          </div>

          <style>{`
            .preview-switch{display:flex;gap:8px;margin:0 0 12px;flex-wrap:wrap}
            .preview-switch button{border:1px solid #dfe6dc;background:#fff;color:#52604f;border-radius:9px;padding:9px 13px;cursor:pointer;font:inherit}
            .preview-switch button.active{background:#718B70;color:#fff;border-color:#718B70}
            .planner-cover-preview{position:relative;display:flex;align-items:stretch;justify-content:center;overflow:hidden;min-height:680px;padding:34px 24px;box-sizing:border-box}
            .cover-preview-content{width:100%;display:flex;flex-direction:column;align-items:center;justify-content:space-between;gap:18px;text-align:center;z-index:1}
            .cover-label-preview{box-sizing:border-box;display:flex;align-items:center;justify-content:center;text-align:center;margin-left:auto;margin-right:auto;padding:5px 8px;white-space:pre-wrap;overflow-wrap:anywhere;border-radius:3px}
            .cover-label-preview.planner-title{font-size:clamp(20px,3vw,32px);line-height:1.2;font-weight:700}
            .cover-label-preview.planner-subtitle{font-size:14px;line-height:1.35}
            .cover-footer-preview{margin-top:auto}
            @media(max-width:700px){.planner-cover-preview{min-height:560px;padding:25px 16px}}
          `}</style>
          <div className="preview-switch" role="group" aria-label="Choisir l’aperçu">
            <button type="button" className={previewMode === 'cover' ? 'active' : ''} onClick={() => setPreviewMode('cover')}>Page de couverture</button>
            <button type="button" className={previewMode === 'interior' ? 'active' : ''} onClick={() => setPreviewMode('interior')}>Page intérieure</button>
          </div>

          <div className="paper-stage">
            {previewMode === 'cover' ? (
              <article
                className={`planner-page planner-cover-preview cover-theme-${coverId || 'personnelle'}`}
                style={{
                  backgroundColor: coverId === 'sombre' ? '#23262B' : coverId === 'nature' ? '#EDF2E7' : coverId === 'professionnelle' ? '#EEF2F8' : coverId === 'coloree' ? '#FFEFD C'.replace(' ', '') : coverId === 'elegante' ? '#F7F1EB' : coverId === 'florale' ? '#FAEDF2' : coverId === 'geometrique' ? '#EDEFF7' : '#FAF9F6',
                  backgroundImage: coverImage ? `url(${coverImage})` : undefined,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center',
                  color: coverId === 'sombre' ? '#E1C07D' : '#373737',
                }}
              >
                <div className="cover-preview-content">
                  {!coverLabelStyles.brand.hidden && <div className="cover-label-preview" style={{ width: `${coverLabelStyles.brand.width}%`, minHeight: `${coverLabelStyles.brand.height * 3.78}px`, color: coverLabelStyles.brand.textColor, background: coverLabelStyles.brand.background }}>PLANNERBUILDER</div>}
                  <div className="planner-cover-mark">❋</div>
                  {!coverLabelStyles.category.hidden && <p className="cover-label-preview" style={{ width: `${coverLabelStyles.category.width}%`, minHeight: `${coverLabelStyles.category.height * 3.78}px`, color: coverLabelStyles.category.textColor, background: coverLabelStyles.category.background }}>{selected.category.toUpperCase()}</p>}
                  {!coverLabelStyles.title.hidden && <h2 className="cover-label-preview planner-title" style={{ width: `${coverLabelStyles.title.width}%`, minHeight: `${coverLabelStyles.title.height * 3.78}px`, color: coverLabelStyles.title.textColor, background: coverLabelStyles.title.background }}>{content.title}</h2>}
                  {!coverLabelStyles.subtitle.hidden && <p className="cover-label-preview planner-subtitle" style={{ width: `${coverLabelStyles.subtitle.width}%`, minHeight: `${coverLabelStyles.subtitle.height * 3.78}px`, color: coverLabelStyles.subtitle.textColor, background: coverLabelStyles.subtitle.background }}>{content.subtitle}</p>}
                  {!coverLabelStyles.footer.hidden && <div className="cover-label-preview cover-footer-preview" style={{ width: `${coverLabelStyles.footer.width}%`, minHeight: `${coverLabelStyles.footer.height * 3.78}px`, color: coverLabelStyles.footer.textColor, background: coverLabelStyles.footer.background }}>COUVERTURE</div>}
                </div>
              </article>
            ) : (
              <article className={`planner-page planner-style-${visualStyle}`} style={{ backgroundColor: background }}>
                <div className="page-topline"><span>MON PLANNER</span><span>✳</span></div>
                <p className="planner-kicker">{selected.category.toUpperCase()}</p>
                <h2 className="planner-title">{content.title}</h2>
                <p className="planner-subtitle">{content.subtitle}</p>
                <div className="planner-date"><span>DATE</span><span className="date-line" /></div>
                <div className="planner-sections">
                  {content.sections.map((section, index) => (
                    <section className={`planner-section section-${index}`} key={`${section}-${index}`}>
                      <h3><span>{['✳', '◇', '○', '✦'][index]}</span> {section}</h3>
                      {index === 1 && selectedId === 'weekly' ? (
                        <div className="week-grid">{['L', 'M', 'M', 'J', 'V', 'S', 'D'].map((day, i) => <div key={`${day}-${i}`}><b>{day}</b><span /></div>)}</div>
                      ) : index === 1 && selectedId === 'monthly' ? (
                        <div className="month-grid">{Array.from({ length: 21 }, (_, i) => <span key={i}>{i + 1}</span>)}</div>
                      ) : (
                        <div className="writing-lines">{(index === 0 ? content.rows : ['', '', '']).map((row, i) => <div className="writing-row" key={i}>{['habits', 'student', 'food'].includes(selectedId) ? <span className="empty-check" /> : null}{row && <span>{row}</span>}</div>)}</div>
                      )}
                    </section>
                  ))}
                </div>
                <footer className="page-footer"><span>UNE PAGE À LA FOIS</span><span>01</span></footer>
              </article>
            )}
          </div>
          <p className="preview-caption">{previewMode === 'cover' ? 'Aperçu de la couverture : les réglages des étiquettes sont visibles ici.' : 'Aperçu intérieur : le style des pages intérieures reste indépendant de la couverture.'}</p>
        </section>

        <aside className="settings panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">ÉTAPE 2</p>
              <h2>Personnaliser</h2>
            </div>
            <span className="settings-icon">⚙</span>
          </div>

          <div className="setting-group label-editor">
            <p className="field-label">Personnalisation des étiquettes de couverture uniquement</p>
            <p className="helper-text">Ces réglages ne changent pas les étiquettes des pages intérieures.</p>
            {[
              ['brand', 'PLANNERBUILDER'],
              ['title', 'Titre principal'],
              ['subtitle', 'Sous-titre'],
              ['category', 'Catégorie'],
              ['footer', 'COUVERTURE'],
            ].map(([key, label]) => {
              const style = coverLabelStyles[key]
              return <div className="label-style-editor" key={key}>
                <strong>{label}</strong>
                <label>Largeur (%) <input type="number" min="10" max="100" value={style.width} onChange={e => updateCoverLabelStyle(key, 'width', Math.max(10, Math.min(100, Number(e.target.value) || 10)))} /></label>
                <label>Hauteur (mm) <input type="number" min="5" max="40" value={style.height} onChange={e => updateCoverLabelStyle(key, 'height', Math.max(5, Math.min(40, Number(e.target.value) || 5)))} /></label>
                <label>Couleur du texte <input type="color" value={style.textColor} onChange={e => updateCoverLabelStyle(key, 'textColor', e.target.value)} /></label>
                <label>Arrière-plan <input type="color" value={style.background} onChange={e => updateCoverLabelStyle(key, 'background', e.target.value)} /></label>
                <label className="label-hide-control"><input type="checkbox" checked={!!style.hidden} onChange={e => updateCoverLabelStyle(key, 'hidden', e.target.checked)} /> Masquer cette étiquette</label>
              </div>
            })}
          </div>

          <div className="setting-group">
            <label className="field-label" htmlFor="visual-style">Style visuel</label>
            <select id="visual-style" value={visualStyle} onChange={(event) => setVisualStyle(event.target.value)}>
              <option value="minimaliste">Minimaliste</option>
              <option value="colore">Coloré</option>
              <option value="elegant">Élégant</option>
              <option value="compact">Compact</option>
              <option value="professionnel">Professionnel</option>
              <option value="nature">Nature</option>
            </select>
          </div>

          <div className="setting-group">
            <label className="field-label" htmlFor="cover-choice">Couverture</label>
            <select id="cover-choice" value={coverId} onChange={(event) => setCoverId(event.target.value)}>
              <option value="minimaliste">Minimaliste (par défaut)</option>
              <option value="minimaliste">Minimaliste</option>
              <option value="nature">Nature</option>
              <option value="professionnelle">Professionnelle</option>
              <option value="coloree">Colorée</option>
              <option value="elegante">Élégante</option>
              <option value="florale">Florale</option>
              <option value="geometrique">Géométrique</option>
              <option value="sombre">Sombre</option>
            </select>
            <label className="field-label" htmlFor="cover-upload">Ou importer une couverture (JPG, PNG ou WebP)</label>
            <input
              id="cover-upload"
              type="file"
              accept="image/jpeg,image/png,image/webp"
              onChange={(event) => {
                const file = event.target.files?.[0]
                if (!file) return
                if (file.size > 10 * 1024 * 1024) {
                  setNotice('Image trop volumineuse : limite de 10 Mo.')
                  event.target.value = ''
                  return
                }
                const reader = new FileReader()
                reader.onload = () => {
                  setCoverImage(String(reader.result || ''))
                  setCoverId('')
                  setNotice('Couverture personnelle chargée.')
                }
                reader.onerror = () => setNotice('Impossible de lire cette image.')
                reader.readAsDataURL(file)
              }}
            />
            {coverImage && (
              <button type="button" className="reset-button" onClick={() => {
                setCoverImage('')
                setNotice('Image de couverture retirée. Choisissez une couverture prédéfinie.')
              }}>
                Retirer mon image
              </button>
            )}
            <small className="helper">La couverture sera la page 1 du PDF. Le planner commencera en page 2.</small>
          </div>

          <div className="setting-group">
            <label className="field-label" htmlFor="pages">Nombre de pages</label>
            <div className="number-control">
              <button type="button" onClick={() => setPages((value) => Math.max(1, value - 1))} aria-label="Diminuer le nombre de pages">−</button>
              <input id="pages" type="number" min="1" max="365" value={pages} onChange={(event) => setPages(Math.max(1, Math.min(365, Number(event.target.value) || 1)))} />
              <button type="button" onClick={() => setPages((value) => Math.min(365, value + 1))} aria-label="Augmenter le nombre de pages">+</button>
            </div>
            <small className="helper">De 1 à 365 pages dans cette version de démonstration.</small>
          </div>

          <div className="setting-group">
            <span className="field-label">Couleur principale</span>
            <div className="color-control">
              <label className="color-swatch" style={{ background: primary }} htmlFor="primary-color" />
              <input id="primary-color" type="color" value={primary} onChange={(event) => setPrimary(event.target.value)} />
              <code>{primary.toUpperCase()}</code>
            </div>
          </div>

          <div className="setting-group">
            <span className="field-label">Fond des pages</span>
            <div className="color-control">
              <label className="color-swatch paper-swatch" style={{ background: background }} htmlFor="background-color" />
              <input id="background-color" type="color" value={background} onChange={(event) => setBackground(event.target.value)} />
              <code>{background.toUpperCase()}</code>
            </div>
          </div>

          <div className="setting-group">
            <span className="field-label">Arrière-plan des titres</span>
            <div className="color-control">
              <label
                className="color-swatch"
                style={{ background: titleBackground }}
                htmlFor="title-background-color"
              />
              <input
                id="title-background-color"
                type="color"
                value={titleBackground}
                onChange={(event) => setTitleBackground(event.target.value)}
              />
              <code>{titleBackground.toUpperCase()}</code>
            </div>
          </div>

          <div className="setting-group">
            <span className="field-label">Couleur du texte des titres</span>
            <div className="color-control">
              <label
                className="color-swatch"
                style={{ background: titleTextColor }}
                htmlFor="title-text-color"
              />
              <input
                id="title-text-color"
                type="color"
                value={titleTextColor}
                onChange={(event) => setTitleTextColor(event.target.value)}
              />
              <code>{titleTextColor.toUpperCase()}</code>
            </div>
          </div>

          <div className="setting-group">
            <label className="field-label" htmlFor="font">Typographie</label>
            <select id="font" value={font} onChange={(event) => setFont(event.target.value)}>
              <option value="moderne">Moderne</option>
              <option value="classique">Classique</option>
              <option value="elegante">Élégante</option>
            </select>
          </div>

          <div className="setting-group">
            <span className="field-label">Densité de la page</span>
            <div className="segmented">
              {['compacte', 'confortable'].map((value) => (
                <button key={value} type="button" className={density === value ? 'active' : ''} onClick={() => setDensity(value)}>
                  {value === 'compacte' ? 'Compacte' : 'Aérée'}
                </button>
              ))}
            </div>
          </div>

          <button className="reset-button" type="button" onClick={() => {
            setPrimary('#718B70')
            setBackground('#F7F5EF')
            setTitleBackground('#718B70')
            setTitleTextColor('#FFFFFF')
            setFont('moderne')
            setDensity('confortable')
            setVisualStyle('minimaliste')
            setNotice('')
          }}>
            ↺ Réinitialiser le style
          </button>

          <div className="export-area">
            <button className="export-button" type="button" onClick={exportPDF}>
              <span>↓</span> Exporter en PDF
            </button>
            <p>Le PDF sera généré et téléchargé directement sur votre appareil.</p>
          </div>
        </aside>
      </div>

      {!isAdmin && (
        <section
          className="pro-upgrade"
          aria-labelledby="pro-upgrade-title"
          style={{
            maxWidth: 1100,
            margin: '32px auto',
            padding: '28px',
            border: '1px solid #dfe6dc',
            borderRadius: 18,
            background: '#fbfcf9',
          }}
        >
          <p className="eyebrow">
            {plan === 'pro' ? 'VOTRE ABONNEMENT PRO' : 'PASSEZ À LA VERSION PRO'}
          </p>
          <h2 id="pro-upgrade-title" style={{ marginTop: 6 }}>
            {plan === 'pro' ? 'Renouvelez votre abonnement' : 'Libérez tout votre potentiel'}
          </h2>
          <p style={{ color: '#667064', margin: '8px 0 20px' }}>
            {plan === 'pro'
              ? 'Choisissez une durée pour prolonger votre accès à PlannerBuilder Pro.'
              : 'Débloquez les exports PDF illimités et profitez de PlannerBuilder Pro.'}
          </p>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
              gap: 16,
            }}
          >
            <article style={{ padding: 20, borderRadius: 14, border: '1px solid #dfe6dc', background: '#fff' }}>
              <h3 style={{ margin: '0 0 8px' }}>Pro mensuel</h3>
              <p style={{ fontSize: 28, fontWeight: 700, margin: '0 0 4px' }}>2 $</p>
              <p style={{ color: '#667064', margin: '0 0 16px' }}>30 jours d’accès Pro</p>
              <a
                href={WHOP_MONTHLY_URL}
                target="_blank"
                rel="noopener noreferrer"
                style={{ display: 'inline-block', padding: '11px 18px', borderRadius: 9, background: '#718B70', color: '#fff', textDecoration: 'none', fontWeight: 700 }}
              >
                {plan === 'pro' ? 'Renouveler 30 jours' : 'Choisir mensuel'}
              </a>
            </article>
            <article style={{ padding: 20, borderRadius: 14, border: '1px solid #dfe6dc', background: '#fff' }}>
              <h3 style={{ margin: '0 0 8px' }}>Pro annuel</h3>
              <p style={{ fontSize: 28, fontWeight: 700, margin: '0 0 4px' }}>20 $</p>
              <p style={{ color: '#667064', margin: '0 0 16px' }}>365 jours d’accès Pro</p>
              <a
                href={WHOP_ANNUAL_URL}
                target="_blank"
                rel="noopener noreferrer"
                style={{ display: 'inline-block', padding: '11px 18px', borderRadius: 9, background: '#263b2b', color: '#fff', textDecoration: 'none', fontWeight: 700 }}
              >
                {plan === 'pro' ? 'Renouveler 365 jours' : 'Choisir annuel'}
              </a>
            </article>
          </div>
          <small style={{ display: 'block', marginTop: 16, color: '#778074' }}>
            Le paiement est traité sur Whop. L’activation et la prolongation de l’abonnement doivent être confirmées par le webhook sécurisé du serveur.
          </small>
        </section>
      )}

      {notice && <div className="notice" role="status">{notice}</div>}

      <footer className="app-footer">
        <span>PlannerBuilder</span>
        <span>Créez avec intention. Organisez avec simplicité.</span>
      </footer>
    </main>
  )
}



function AppWithAuth() {
  return (
    <AuthGate>
      <App />
    </AuthGate>
  )
}

export default AppWithAuth
